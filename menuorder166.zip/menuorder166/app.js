const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.use(express.static('public'));

const session = require('express-session');
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true,
}));


app.get('/', (req, res) => {
  res.render('index');
});

app.get('/register', (req, res) => {
    res.render('register');
  });
  
  app.post('/register', (req, res) => {
    const { full_name, phone, email, city, username, password } = req.body;
  
    // Insert into user table
    db.query('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', [username, password, 'customer'], (err, result) => {
        if (err) throw err;
  
        const userId = result.insertId;
  
        // Insert into customer table
        db.query('INSERT INTO customer (id, full_name, phone, email, city) VALUES (?, ?, ?, ?, ?)', 
        [userId, full_name, phone, email, city], (err) => {
            if (err) throw err;
  
            res.redirect('/login');
        });
    });
  });

  app.get('/login', (req, res) => {
    res.render('login');
  });
  
  app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const query = `SELECT * FROM users WHERE username = ? AND password = ?`;
    db.query(query, [username, password], (err, result) => {
      if (err) throw err;
      if (result.length > 0) {
        const user = result[0];
        req.session.user_id = user.id; // Store user_id in session
        if (user.role === 'chef') {
          res.redirect('/chef_home');
        } else {
          res.redirect('/customer_home');
        }
      } else {
        res.send('Invalid Credentials');
      }
    });
  });

  app.get('/customer_home', (req, res) => {
    const user_id = req.session.user_id; 
    db.query('SELECT * FROM menu_items', (err, items) => {
      if (err) throw err;
      res.render('customer_home', { items, user_id }); 
    });
  });

  app.post('/add_to_cart', (req, res) => {
    const { item_id, quantity } = req.body;
    const user_id = req.session.user_id;
  
    if (!user_id) {
      return res.status(401).send('User not logged in');
    }
  
    const query = 'INSERT INTO cart (user_id, item_id, quantity) VALUES (?, ?, ?)';
    db.query(query, [user_id, item_id, quantity], (err) => {
      if (err) throw err;
      res.redirect('/customer_home');
    });
  });

  app.get('/add_item', (req, res) => {
    res.render('add_item');
  });
  
  app.post('/add_item', (req, res) => {
    const { name, price } = req.body;
    db.query('INSERT INTO menu_items (name, price) VALUES (?, ?)', [name, price], (err) => {
      if (err) throw err;
      res.redirect('/chef_home');
    });
  });

  app.get('/chef_orders', (req, res) => {
    const query = `
       SELECT orders.id, orders.user_id, users.username, menu_items.name, orders.quantity
  FROM orders
  JOIN users ON orders.user_id = users.id
  JOIN menu_items ON orders.item_id = menu_items.id
  WHERE orders.status = 'pending'
  ORDER BY orders.id DESC;
  
    `;
    
  
    db.query(query, (err, orders) => {
      if (err) throw err;
      res.render('chef_orders', { orders });
    });
  });

  app.get('/chef_home', (req, res) => {
    db.query('SELECT * FROM menu_items', (err, items) => {
      if (err) throw err;
      res.render('chef_home', { items });
    });
  });

  app.post('/delete_item/:id', (req, res) => {
    const id = req.params.id;
    db.query('DELETE FROM menu_items WHERE id = ?', [id], (err) => {
      if (err) throw err;
      res.redirect('/chef_home');
    });
  });

  app.post('/update_order_status/:id', (req, res) => {
    const orderId = req.params.id;
    const query = `UPDATE orders SET status = 'completed' WHERE id = ?`;
    db.query(query, [orderId], (err) => {
        if (err) throw err;
        res.redirect('/chef_orders');
    });
  });

  app.get('/chef_orders_completed', (req, res) => {
    const query = `
        SELECT orders.id, orders.user_id, users.username, menu_items.name, orders.quantity
        FROM orders
        JOIN users ON orders.user_id = users.id
        JOIN menu_items ON orders.item_id = menu_items.id
        WHERE orders.status = 'completed';
    `;
    db.query(query, (err, results) => {
        if (err) throw err;
        res.render('chef_orders_completed', { orders: results });
    });
  });

  app.get('/changepassword', (req, res) => {
    res.render('changepassword');
  });
  
  app.post('/changepassword', (req, res) => {
    const userId = req.session.user_id;  // Assuming the user ID is stored in the session after login
    const { current_password, new_password } = req.body;
  
    // Verify the current password
    db.query('SELECT password FROM users WHERE id = ?', [userId], (err, results) => {
        if (err) throw err;
  
        if (results.length > 0) {
            const storedPassword = results[0].password;
  
            if (storedPassword === current_password) {
                // Passwords match, update to the new password
                db.query('UPDATE users SET password = ? WHERE id = ?', [new_password, userId], (err) => {
                    if (err) throw err;
  
                    res.send('Password updated successfully.');
                });
            } else {
                // Current password does not match
                res.send('Current password is incorrect.');
            }
        } else {
            res.send('User not found.');
        }
    });
  });



app.get('/cart/:user_id', (req, res) => {
    const user_id = req.params.user_id;
    const query = `
      SELECT menu_items.name, menu_items.price, cart.quantity, cart.item_id
      FROM cart
      JOIN menu_items ON cart.item_id = menu_items.id
      WHERE cart.user_id = ?
    `;
    db.query(query, [user_id], (err, items) => {
      if (err) throw err;
      console.log(items)
      res.render('cart', { items });
    });
  });

  app.post('/update_cart', (req, res) => {
    const userId = req.session.user_id; // or however you store the user's ID
    const updates = [];
  
    
  
    for (const [key, value] of Object.entries(req.body)) {
      if (key.startsWith('quantity_')) {
        const itemId = key.split('_')[1];
        const quantity = parseInt(value, 10);
  
        if (!isNaN(quantity) && quantity > 0) {
          updates.push({ itemId, quantity });
        }
      }
    }
  
  
  
    const updatePromises = updates.map(update => {
      return new Promise((resolve, reject) => {
        db.query('UPDATE cart SET quantity = ? WHERE user_id = ? AND item_id = ?', [update.quantity, userId, update.itemId], (err) => {
          if (err) {
            
            reject(err);
          } else {
            
            resolve();
          }
        });
      });
    });
  
    Promise.all(updatePromises)
      .then(() => {
        res.redirect('/cart/' + userId);
      })
      .catch((err) => {
        res.status(500).send('Error updating cart');
      });
  });

  app.post('/remove_item/:id', (req, res) => {
    const itemId = req.params.id;
    const userId = req.session.user_id; // or however you store the user's ID
  
    db.query('DELETE FROM cart WHERE user_id = ? AND item_id = ?', [userId, itemId], (err) => {
      if (err) throw err;
      res.redirect('/cart/' + userId);
    });
  });
  
  
  app.post('/clear_cart', (req, res) => {
    const userId = req.session.user_id; // or however you store the user's ID
  
    db.query('DELETE FROM cart WHERE user_id = ?', [userId], (err) => {
      if (err) throw err;
      res.redirect('/cart/' + userId);
    });
  });

  app.post('/place_order', (req, res) => {
    const user_id = req.session.user_id;
  
    const insertQuery = `
        INSERT INTO orders (user_id, item_id, quantity)
        SELECT user_id, item_id, quantity FROM cart WHERE user_id = ?;
    `;
  
    const deleteQuery = `
        DELETE FROM cart WHERE user_id = ?;
    `;
  
    // Execute the insert query first
    db.query(insertQuery, [user_id], (err) => {
        if (err) throw err;
  
        // Then execute the delete query
        db.query(deleteQuery, [user_id], (err) => {
            if (err) throw err;
  
            // Redirect to order confirmation page or wherever you want
            res.redirect('/order_confirmation');
        });
    });
  });
  
  app.get('/order_confirmation', (req, res) => {
    res.render('order_confirmation');
  });

  const PORT = 3007;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});